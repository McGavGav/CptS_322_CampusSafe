from django.shortcuts import render
from .models import SafetyResource

def resources_view(request):
    resources = SafetyResource.objects.all()
    return render(request, 'safety_resources/resources.html', {'resources': resources})


